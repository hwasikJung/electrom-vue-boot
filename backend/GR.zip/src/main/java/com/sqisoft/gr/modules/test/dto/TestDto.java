package com.sqisoft.gr.modules.test.dto;

import lombok.Data;

@Data
public class TestDto {

	private String department;
	private Integer amount;
	private Integer year;
}
