package com.sqisoft.gr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrApplicationTests {

	@Test
	void contextLoads() {
	}

}
